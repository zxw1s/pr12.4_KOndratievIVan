﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace var6
{
    public partial class Form1 :Form
    {
        public Form1 ()
        {
            InitializeComponent();
        }
        Pokupatel[] pk = new Pokupatel[10];
        int k=0;
        private void button1_Click (object sender, EventArgs e)
        {
            try
            {
                listBox1.Items.Add(pk[comboBox2.SelectedIndex].Info());
            }
            catch { }
        }
        private void button2_Click (object sender, EventArgs e)
        {
            try
            {
                pk[comboBox2.SelectedIndex].Buy(Convert.ToInt32(comboBox1.SelectedIndex), Convert.ToInt32(numericUpDown1.Value));
            }
            catch{ }
        }
        private void button3_Click (object sender, EventArgs e)
        {
                try
                {
                    listBox1.Items.Add(pk[comboBox2.SelectedIndex].Sm_nastr());
                }
                catch { }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                pk[k] = new Pokupatel(Convert.ToInt32(textBox1.Text));
                MessageBox.Show($"Данные внесены\nосталось еще {10 - (k + 1)} покупателей");
                k++;
                if (k == 10)
                {
                    button4.Visible = false;
                    button1.Visible = true;
                    button2.Visible = true;
                    button3.Visible = true;
                    listBox1.Visible = true;
                    comboBox1.Visible = true;
                    textBox1.Visible = false;
                    numericUpDown1.Visible = true;
                    label1.Visible = false;
                    comboBox2.Visible = true;
                    button5.Visible = true;
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("error");
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            for(int i = 1; i <= 10; i++)
            {
                comboBox2.Items.Add($"Клиент {i}");
            }   
        }
        private void button5_Click (object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
}
