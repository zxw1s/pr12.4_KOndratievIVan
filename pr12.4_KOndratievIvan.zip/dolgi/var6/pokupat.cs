﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace var6
{
    public class Pokupatel
    {
        private double wallet;
        private double emotions;
        private string[] product={ "перец","соль","растишка","пирог","пельмени","фанта","доширак"};
        private int kol;
        private int price;
        private string name;
        private int ceni;


        public  Pokupatel(int wallet)
        {
            this.wallet = wallet;
            this.emotions = 10;
        }
        

        public void Buy(int product_number, int kol)
        {
            switch (product_number)
            {
                case 0:
                    this.price = 20;
                    break;
                case 1:
                    this.price = 111;
                    break;
                case 2:
                    this.price = 329;
                    break;
                case 3:
                    this.price = 777;
                    break;
                case 4:
                    this.price = 52;
                    break;
                case 5:
                    this.price = 56;
                    break;
                case 6:
                    this.price = 69;
                    break;
            }
            this.kol=kol;
            if (price*this.kol <= wallet)
            {
                this.wallet -= this.price*this.kol;
                this.ceni+= this.price * this.kol;
                if (this.name != null)
                {
                    if (!this.name.Contains(this.product[product_number]))
                    {
                        this.name += this.product[product_number] + " ";
                    }
                }
                else
                {
                    this.name += this.product[product_number] + " ";
                }
                this.emotions += this.price * 0.5;
            }
            else
            {
                this.emotions -= this.price*kol - this.wallet;
            }
        }

        public string Sm_nastr ()
        {
            if (this.emotions > 15)
                return "все классно";
            if (this.emotions >= 5 && this.emotions < 15)
                return "неплохо";
            if (this.emotions >= -10 && this.emotions < 5)
                return "плохое";
            else
                return "все плохо";
        }

        public string Info()
        {
            return "Куплено \n" + this.name +
                "Стоимость \n" + (this.ceni);
        }

    }
}
